import { Component, Inject, OnInit } from '@angular/core';
import { Author } from 'src/app/models/author.interface';
import { AuthorFactory } from 'src/app/services/author-factory';
import { authorList } from 'src/app/services/author-list-data';
import { AuthorService } from 'src/app/services/author.service';
import { Authors } from 'src/app/services/custom-di-tokens';

@Component({
    selector: 'app-root',
    templateUrl: './root.component.html',
    styleUrls: ['./root.component.css'],
    providers: [
        // { provide: 'Authors', useValue: authorList }
        // { provide: Authors, useValue: authorList },
        // { provide: 'NewAuthors', useExisting: Authors }

        // { provide: AuthorService, useClass: AuthorService }
        // AuthorService

        { provide: 'ENVIRONMENT', useValue: { "production": false } },
        {
            provide: AuthorService,
            useFactory: AuthorFactory,
            deps: [
                'ENVIRONMENT'
            ]
        }
    ]
})
export class RootComponent implements OnInit {
    list?: Array<Author>;
    selectedAuthor?: Author;

    // constructor(@Inject('Authors') private authors: Array<any>) { }
    // constructor(@Inject(Authors) private authors: Array<any>) { }
    // constructor(@Inject('NewAuthors') private authors: Array<any>) { }

    // constructor(@Inject(AuthorService) private authorService: any) { }
    constructor(private authorService: AuthorService) { }

    ngOnInit() {
        // this.list = this.authors;
        this.list = this.authorService.Authors;
    }

    selectAuthor(a: Author) {
        this.selectedAuthor = a;
    }

    isSelected(a: Author) {
        return this.selectedAuthor === a;
    }
}
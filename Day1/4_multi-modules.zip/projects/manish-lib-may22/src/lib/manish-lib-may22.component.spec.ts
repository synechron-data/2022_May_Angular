import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManishLibMay22Component } from './manish-lib-may22.component';

describe('ManishLibMay22Component', () => {
  let component: ManishLibMay22Component;
  let fixture: ComponentFixture<ManishLibMay22Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManishLibMay22Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManishLibMay22Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

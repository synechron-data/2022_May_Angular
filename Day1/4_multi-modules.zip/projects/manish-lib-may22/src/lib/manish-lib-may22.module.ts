import { NgModule } from '@angular/core';
import { ManishLibMay22Component } from './manish-lib-may22.component';



@NgModule({
  declarations: [
    ManishLibMay22Component
  ],
  imports: [
  ],
  exports: [
    ManishLibMay22Component
  ]
})
export class ManishLibMay22Module { }

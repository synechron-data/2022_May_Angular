import { TestBed } from '@angular/core/testing';

import { ManishLibMay22Service } from './manish-lib-may22.service';

describe('ManishLibMay22Service', () => {
  let service: ManishLibMay22Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ManishLibMay22Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

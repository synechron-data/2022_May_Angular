import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'manish-lib-component',
  template: `
    <h1 class="text-warning">This is a component, exposed from my-lib</h1>
  `,
  styles: [
  ]
})
export class ManishLibMay22Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

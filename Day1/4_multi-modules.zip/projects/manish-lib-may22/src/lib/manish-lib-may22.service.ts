import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ManishLibMay22Service {

  constructor() { }
}

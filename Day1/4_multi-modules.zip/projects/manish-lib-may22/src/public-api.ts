/*
 * Public API Surface of manish-lib-may22
 */

export * from './lib/manish-lib-may22.service';
export * from './lib/manish-lib-may22.component';
export * from './lib/manish-lib-may22.module';

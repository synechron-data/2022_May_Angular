import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-one',
  template: `
    <h1 class="text-primary">
      Hello from Component One - Module One
    </h1>
    <app-hello></app-hello>
    <app-scomp></app-scomp>
  `,
  styles: [
  ]
})
export class CompOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

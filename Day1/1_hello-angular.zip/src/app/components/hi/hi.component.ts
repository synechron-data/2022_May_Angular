import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hi',
  template: `
    <h1>
      hi works!
    </h1>
  `,
  styles: [
  ]
})
export class HiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

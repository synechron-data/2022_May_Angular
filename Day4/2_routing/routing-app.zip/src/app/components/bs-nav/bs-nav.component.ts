import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';

@Component({
  selector: 'bs-nav',
  templateUrl: './bs-nav.component.html',
  styleUrls: ['./bs-nav.component.css']
})
export class BsNavComponent implements OnInit, OnDestroy {
  private isLoggedIn: boolean;
  sub?: Subscription;

  constructor() {
    this.isLoggedIn = false;
  }

  ngOnInit(): void {
  }

  get IsLoggedIn() { return this.isLoggedIn; }

  ngOnDestroy(): void {

  }
}

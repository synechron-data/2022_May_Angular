import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import { catchError, delay, retry } from 'rxjs/operators';
import { environment } from "src/environments/environment";
import { Post } from "../models/post.model";

@Injectable()
export class PostsService {
    url: string;

    constructor(private httpClient: HttpClient) {
        this.url = environment.postsUrl;
    }

    // getAllPosts() {
    //     return this.httpClient.get<Array<Post>>(this.url);
    // }

    getAllPosts() {
        return this.httpClient.get<Array<Post>>(this.url).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('getAllPosts', []))
        );
    }

    private _handleError<T>(operation = 'operation', result?: T) {
        return (err: HttpErrorResponse): Observable<T> => {
            // Error Logging
            // console.log(err);
            console.error(`${operation} failed: ${err.message}`);
            return throwError('Connection Error, please try again later...');
        }
    }
}

// class Queue {
//     data: number[];

//     constructor() {
//         this.data = [];
//     }

//     push(d: number) {
//         this.data.push(d);
//     }

//     getData(): number[] {
//         return this.data;
//     }
// }

// class Queue {
//     data: any[];

//     constructor() {
//         this.data = [];
//     }

//     push(d: any) {
//         this.data.push(d);
//     }

//     pop(): any {
//         return this.data.shift();
//     }
// }

// class Queue<T> {
//     data: T[];

//     constructor() {
//         this.data = [];
//     }

//     push(d: T) {
//         this.data.push(d);
//     }

//     pop(): T | undefined {
//         return this.data.shift();
//     }
// }

// var q = new Queue<number>();
// q.push(10);

// var q1 = new Queue<string>();
// q1.push("abc");
// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
// import { Post } from 'src/app/models/post.model';
// import { environment } from 'src/environments/environment';
// import { Subscription } from 'rxjs';

// @Component({
//   selector: 'app-root',
//   templateUrl: './root.component.html',
//   styleUrls: ['./root.component.css']
// })
// export class RootComponent implements OnInit, OnDestroy {
//   url: string;
//   message: string;
//   posts?: Array<Post>;
//   get_sub?: Subscription;

//   constructor(private httpClient: HttpClient) {
//     this.url = environment.postsUrl;
//     this.message = "Loading Data, please wait...";
//   }

//   ngOnInit(): void {
//     this.get_sub = this.httpClient.get<Array<Post>>(this.url).subscribe(resData => {
//       this.posts = [...resData];
//       this.message = "";
//     }, (err: HttpErrorResponse) => {
//       this.message = err.message;
//     });
//   }

//   ngOnDestroy(): void {
//     this.get_sub?.unsubscribe();
//   }
// }

// ---------------------------------------------------------------------------

// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { HttpErrorResponse } from '@angular/common/http';
// import { Post } from 'src/app/models/post.model';
// import { Subscription } from 'rxjs';
// import { PostsService } from 'src/app/services/posts.service';

// @Component({
//   selector: 'app-root',
//   templateUrl: './root.component.html',
//   styleUrls: ['./root.component.css'],
//   providers: [PostsService]
// })
// export class RootComponent implements OnInit, OnDestroy {
//   message: string;
//   posts?: Array<Post>;
//   get_sub?: Subscription;

//   constructor(private postsService: PostsService) {
//     this.message = "Loading Data, please wait...";
//   }

//   ngOnInit(): void {
//     this.get_sub = this.postsService.getAllPosts().subscribe(resData => {
//       this.posts = [...resData];
//       this.message = "";
//     }, (err: HttpErrorResponse) => {
//       this.message = err.message;
//     });
//   }

//   ngOnDestroy(): void {
//     this.get_sub?.unsubscribe();
//   }
// }


// ---------------------------------------------------------------------------

import { Component, OnDestroy, OnInit } from '@angular/core';
import { Post } from 'src/app/models/post.model';
import { Subscription } from 'rxjs';
import { PostsService } from 'src/app/services/posts.service';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css'],
  providers: [PostsService]
})
export class RootComponent implements OnInit, OnDestroy {
  message: string;
  posts?: Array<Post>;
  get_sub?: Subscription;

  constructor(private postsService: PostsService) {
    this.message = "Loading Data, please wait...";
  }

  ngOnInit(): void {
    this.get_sub = this.postsService.getAllPosts().subscribe(resData => {
      this.posts = [...resData];
      this.message = "";
    }, (err: string) => {
      this.message = err;
    });
  }

  ngOnDestroy(): void {
    this.get_sub?.unsubscribe();
  }
}